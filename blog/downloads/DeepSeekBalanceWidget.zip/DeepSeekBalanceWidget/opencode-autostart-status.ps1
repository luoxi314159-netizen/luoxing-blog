﻿$dir  = Split-Path -Parent $MyInvocation.MyCommand.Path
$flag = Join-Path $dir 'opencode-autostart.json'

$enabled = $false
if (Test-Path $flag) {
  try { $enabled = [bool](Get-Content $flag -Raw | ConvertFrom-Json).enabled } catch { $enabled = $false }
}

$watchScript = Join-Path $dir 'opencode-watch.ps1'
$running = @(
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -and $_.CommandLine -like '*-File*opencode-watch.ps1*' }
).Count -gt 0

$startupLnk = Join-Path ([Environment]::GetFolderPath('Startup')) 'DeepSeekBalance-OpenCodeWatch.lnk'
$autostart = Test-Path $startupLnk

$ocOpen = @(Get-Process -Name 'OpenCode', 'opencode' -ErrorAction SilentlyContinue).Count -gt 0

Write-Host ''
Write-Host ('开关状态  : ' + $(if ($enabled) { '已开启' } else { '已关闭' }))
Write-Host ('后台监听  : ' + $(if ($running) { '运行中' } else { '未运行' }))
Write-Host ('开机启动项: ' + $(if ($autostart) { '已设置' } else { '未设置' }))
Write-Host ('OpenCode  : ' + $(if ($ocOpen) { '正在运行' } else { '未运行' }))
Write-Host ''
