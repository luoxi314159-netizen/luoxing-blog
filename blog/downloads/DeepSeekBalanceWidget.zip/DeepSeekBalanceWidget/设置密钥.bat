@echo off
chcp 65001 >nul
set "PS=powershell"
where pwsh >nul 2>nul && set "PS=pwsh"
%PS% -NoProfile -ExecutionPolicy Bypass -File "%~dp0set-key.ps1"
exit /b
