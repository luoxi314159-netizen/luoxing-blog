﻿# 设置 / 更新 DeepSeek API Key
# 密钥用 Windows DPAPI 加密后保存到同目录 key.dpapi，只有当前 Windows 用户能解密。

$Root    = Split-Path -Parent $MyInvocation.MyCommand.Path
$KeyFile = Join-Path $Root 'key.dpapi'

Write-Host ''
Write-Host '=== 设置 DeepSeek API Key ===' -ForegroundColor Cyan
Write-Host '获取方式: platform.deepseek.com -> API Keys -> 创建/复制密钥'
Write-Host ''

$sec = Read-Host '粘贴 API Key (输入不回显)' -AsSecureString
if (-not $sec -or $sec.Length -eq 0) {
  Write-Host '未输入内容，已取消。' -ForegroundColor Yellow
  exit 1
}

$sec | ConvertFrom-SecureString | Set-Content -Path $KeyFile -Encoding ASCII

Write-Host ''
Write-Host "已保存: $KeyFile" -ForegroundColor Green
Write-Host '提示: 该文件绑定当前 Windows 用户；换电脑或换用户需要重新设置。'
Write-Host ''
Read-Host '按回车关闭'
