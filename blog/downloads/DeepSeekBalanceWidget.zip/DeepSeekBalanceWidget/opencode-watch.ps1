﻿# 后台监听：检测到 OpenCode（桌面版 / TUI）启动时，自动拉起余额挂件。
# 由「opencode自启-开启.bat」写入启动项并以隐藏窗口运行；开关状态见 opencode-autostart.json。
# 行为：只在 OpenCode「从关闭变为打开」时启动一次挂件；不会强行重启你手动关闭的挂件。

$ErrorActionPreference = 'SilentlyContinue'

# 单实例：若同名互斥体已存在，说明已有监听在运行，直接退出
$script:createdNew = $false
$script:watchMutex = New-Object System.Threading.Mutex($true, 'Local\DeepSeekBalanceOpenCodeWatch', [ref]$script:createdNew)
if (-not $script:createdNew) { exit 0 }

$dir    = Split-Path -Parent $MyInvocation.MyCommand.Path
$flag   = Join-Path $dir 'opencode-autostart.json'
$widget = Join-Path $dir 'widget.ps1'
$intervalSec = 10

function Get-Enabled {
  try { return [bool](Get-Content $flag -Raw | ConvertFrom-Json).enabled } catch { return $false }
}

function Test-WidgetRunning {
  @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -and $_.CommandLine -like '*-File*widget.ps1*' }).Count -gt 0
}

function Test-OpenCodeOpen {
  # 桌面版进程名 OpenCode；TUI 进程名 opencode。忽略常驻后台的 opencode-cli serve。
  @(Get-Process -Name 'OpenCode', 'opencode' -ErrorAction SilentlyContinue).Count -gt 0
}

function Start-Widget {
  if (Test-WidgetRunning) { return }
  if (-not (Test-Path $widget)) { return }
  Start-Process -FilePath 'powershell.exe' -ArgumentList @(
    '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', $widget
  ) -WindowStyle Hidden
}

$wasOpen = $false
while ($true) {
  $isOpen = Test-OpenCodeOpen
  if ((Get-Enabled) -and $isOpen -and (-not $wasOpen)) { Start-Widget }
  $wasOpen = $isOpen
  Start-Sleep -Seconds $intervalSec
}
