﻿param(
  [switch]$Disable
)

$Root    = Split-Path -Parent $MyInvocation.MyCommand.Path
$startup = [Environment]::GetFolderPath('Startup')
$lnk     = Join-Path $startup 'DeepSeekBalanceWidget.lnk'

if ($Disable) {
  if (Test-Path $lnk) { Remove-Item $lnk -Force }
  Write-Host '已取消开机自启。' -ForegroundColor Yellow
  exit 0
}

$ws = New-Object -ComObject WScript.Shell
$s  = $ws.CreateShortcut($lnk)
$s.TargetPath       = 'powershell.exe'
$s.Arguments        = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $Root 'widget.ps1') + '"'
$s.WorkingDirectory = $Root
$s.WindowStyle      = 7
$s.Description      = 'DeepSeek 余额挂件'
$s.Save()

Write-Host "已设置开机自启: $lnk" -ForegroundColor Green
