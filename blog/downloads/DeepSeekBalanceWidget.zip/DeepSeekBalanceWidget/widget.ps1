﻿param(
  [switch]$Test
)

# ============================================================
#  DeepSeek 余额挂件（独立版，不依赖 DSH）
#  - 置顶小窗，默认每 60 秒刷新 DeepSeek 账户余额
#  - 「今日已用」通过余额观测记账（余额下降=消费，上升=充值不计）
#  - 密钥用 Windows DPAPI 加密保存，仅当前 Windows 用户可解密
#  - 多主题：深色/浅色/深海/樱花/终端/半透（右键切换并记忆）
#  - 高峰时段（北京时间工作日 9:00–12:00 / 14:00–18:00，排除法定节假日）启动时醒目提醒
#  首次使用请先运行「设置密钥.bat」
# ============================================================

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$script:Root       = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:KeyFile    = Join-Path $script:Root 'key.dpapi'
$script:UsageFile  = Join-Path $script:Root 'usage.json'
$script:ThemeFile  = Join-Path $script:Root 'theme.json'
$script:OpenCodeFlag = Join-Path $script:Root 'opencode-autostart.json'
$script:HolidaysFile = Join-Path $script:Root 'holidays.json'
$script:BalanceUrl = 'https://api.deepseek.com/user/balance'
$script:RefreshSec = 60

# ---------- 工具函数 ----------
function Get-ApiKey {
  if (-not (Test-Path $script:KeyFile)) { return $null }
  try {
    $sec  = (Get-Content -Path $script:KeyFile -Raw).Trim() | ConvertTo-SecureString
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
    try   { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
  } catch { return $null }
}

function Get-BeijingDay {
  [DateTimeOffset]::UtcNow.ToOffset([TimeSpan]::FromHours(8)).ToString('yyyy-MM-dd')
}

function ConvertTo-Dec([string]$s) {
  [decimal]::Parse([string]$s, [Globalization.CultureInfo]::InvariantCulture)
}

function Get-CurrencySymbol([string]$c) {
  switch ($c) { 'CNY' { '¥' } 'USD' { '$' } default { "$c " } }
}

function C([string]$hex, [int]$alpha = 255) {
  $h = $hex.TrimStart('#')
  $r = [Convert]::ToInt32($h.Substring(0, 2), 16)
  $g = [Convert]::ToInt32($h.Substring(2, 2), 16)
  $b = [Convert]::ToInt32($h.Substring(4, 2), 16)
  [Drawing.Color]::FromArgb($alpha, $r, $g, $b)
}

# ---------- 峰谷时段（北京时间） ----------
# 高峰：周一至周五（不含中国法定节假日）09:00–12:00、14:00–18:00
# 内置 2026 年法定节假日（国务院办公厅 2025-11-04 通知）；
# 其它年份可在同目录 holidays.json 里补 'yyyy-MM-dd' 数组，会自动并入。
$script:Holidays2026 = @(
  '2026-01-01','2026-01-02','2026-01-03',
  '2026-02-15','2026-02-16','2026-02-17','2026-02-18','2026-02-19','2026-02-20','2026-02-21','2026-02-22','2026-02-23',
  '2026-04-04','2026-04-05','2026-04-06',
  '2026-05-01','2026-05-02','2026-05-03','2026-05-04','2026-05-05',
  '2026-06-19','2026-06-20','2026-06-21',
  '2026-09-25','2026-09-26','2026-09-27',
  '2026-10-01','2026-10-02','2026-10-03','2026-10-04','2026-10-05','2026-10-06','2026-10-07'
)

function Get-HolidaySet {
  $set = New-Object 'System.Collections.Generic.HashSet[string]'
  foreach ($d in $script:Holidays2026) { [void]$set.Add($d) }
  if (Test-Path $script:HolidaysFile) {
    try {
      $extra = Get-Content -Path $script:HolidaysFile -Raw | ConvertFrom-Json
      foreach ($d in @($extra)) {
        $s = [string]$d
        if ($s -match '^\d{4}-\d{2}-\d{2}$') { [void]$set.Add($s) }
      }
    } catch { }
  }
  return $set
}
$script:HolidaySet = Get-HolidaySet

function Get-BeijingNow {
  # 调试用：设置环境变量 DSWW_FAKE_NOW='yyyy-MM-dd HH:mm' 可模拟北京时间
  if ($env:DSWW_FAKE_NOW) {
    try {
      return [DateTimeOffset]::ParseExact($env:DSWW_FAKE_NOW, 'yyyy-MM-dd HH:mm',
        [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None)
    } catch { }
  }
  [DateTimeOffset]::UtcNow.ToOffset([TimeSpan]::FromHours(8))
}

function Get-PeakState {
  $now     = Get-BeijingNow
  $day     = $now.ToString('yyyy-MM-dd')
  $dow     = $now.DayOfWeek
  $weekday = ($dow -ne [DayOfWeek]::Saturday) -and ($dow -ne [DayOfWeek]::Sunday)
  $holiday = $script:HolidaySet.Contains($day)
  $t       = $now.TimeOfDay
  $morning   = ($t -ge [TimeSpan]::FromHours(9))  -and ($t -lt [TimeSpan]::FromHours(12))
  $afternoon = ($t -ge [TimeSpan]::FromHours(14)) -and ($t -lt [TimeSpan]::FromHours(18))
  $window = if ($morning) { '上午 09:00–12:00' } elseif ($afternoon) { '下午 14:00–18:00' } else { '' }
  [pscustomobject]@{
    IsPeak  = ($weekday -and (-not $holiday) -and ($morning -or $afternoon))
    Weekday = $weekday
    Holiday = $holiday
    Window  = $window
    Now     = $now
  }
}

$script:peak = (Get-PeakState)
$script:peakShown = $null

# ---------- 主题定义 ----------
$script:Themes = @(
  @{ id='dark';     name='深色'; bg=(C '#181C26'); fg=(C '#EBF0F8'); accent=(C '#7AC8FF'); muted=(C '#8C96A5'); border=(C '#2A3346'); opacity=0.95; radius=10 },
  @{ id='light';    name='浅色'; bg=(C '#F4F6FB'); fg=(C '#1A1D26'); accent=(C '#0A66C2'); muted=(C '#6B7280'); border=(C '#D8DEE9'); opacity=0.98; radius=10 },
  @{ id='ocean';    name='深海'; bg=(C '#07202E'); fg=(C '#D6F5F0'); accent=(C '#3FE0D0'); muted=(C '#6FA8A2'); border=(C '#12455A'); opacity=0.95; radius=10 },
  @{ id='sakura';   name='樱花'; bg=(C '#2A1721'); fg=(C '#FBE6EF'); accent=(C '#FF9EC4'); muted=(C '#B08497'); border=(C '#4A2735'); opacity=0.95; radius=10 },
  @{ id='terminal'; name='终端'; bg=(C '#0A0F0A'); fg=(C '#CDEFCD'); accent=(C '#55FF88'); muted=(C '#6B8F6B'); border=(C '#1E3A1E'); opacity=0.95; radius=6  },
  @{ id='glass';    name='半透'; bg=(C '#EAF2FF'); fg=(C '#10203A'); accent=(C '#0A66C2'); muted=(C '#5B6B85'); border=(C '#FFFFFF', 90); opacity=0.72; radius=16 }
)

function Get-ThemeById([string]$id) {
  $t = $script:Themes | Where-Object { $_.id -eq $id } | Select-Object -First 1
  if ($t) { return $t }
  return $script:Themes[0]
}

$script:theme = $script:Themes[0]

# ---------- 状态 ----------
$script:state = @{
  Balance   = $null
  Currency  = 'CNY'
  Today     = [decimal]0
  Day       = $null
  UpdatedAt = $null
  Error     = $null
}

# ---------- 查询 + 记账 ----------
function Update-Balance {
  $key = Get-ApiKey
  if (-not $key) { $script:state.Error = '未配置密钥'; return }

  try {
    $resp = Invoke-RestMethod -Uri $script:BalanceUrl -Method Get `
              -Headers @{ Authorization = "Bearer $key" } -TimeoutSec 8
  } catch {
    $script:state.Error = '网络异常，沿用上次'
    return
  }

  $infos = @($resp.balance_infos)
  $info  = @($infos | Where-Object { $_.currency -eq 'CNY' }) | Select-Object -First 1
  if (-not $info) { $info = $infos | Select-Object -First 1 }
  if (-not $info -or $null -eq $info.total_balance) {
    $script:state.Error = '返回结构异常'
    return
  }

  try   { $bal = ConvertTo-Dec $info.total_balance }
  catch { $script:state.Error = '金额解析失败'; return }

  $cur   = if ($info.currency) { [string]$info.currency } else { 'CNY' }
  $today = Get-BeijingDay

  $led = $null
  if (Test-Path $script:UsageFile) {
    try { $led = Get-Content -Path $script:UsageFile -Raw | ConvertFrom-Json } catch { $led = $null }
  }
  if (-not $led -or $led.day -ne $today) {
    $consumed = [decimal]0
  } else {
    $consumed = ConvertTo-Dec $led.observed
    $last     = ConvertTo-Dec $led.lastBalance
    $delta    = $last - $bal
    if ($delta -gt 0) { $consumed += $delta }
  }

  $ledger = [ordered]@{
    day         = $today
    lastBalance = $bal.ToString([Globalization.CultureInfo]::InvariantCulture)
    observed    = $consumed.ToString([Globalization.CultureInfo]::InvariantCulture)
    currency    = $cur
    updatedAt   = (Get-Date).ToString('s')
  }
  try {
    ($ledger | ConvertTo-Json) | Set-Content -Path $script:UsageFile -Encoding UTF8
  } catch { }

  $script:state.Balance   = $bal
  $script:state.Currency  = $cur
  $script:state.Today     = $consumed
  $script:state.Day       = $today
  $script:state.UpdatedAt = Get-Date
  $script:state.Error     = $null
}

# ---------- 无界面自检模式 ----------
if ($Test) {
  Update-Balance
  $script:state.GetEnumerator() | ForEach-Object { "{0,-10} = {1}" -f $_.Key, $_.Value }
  $p = Get-PeakState
  "Peak       = {0}  ({1})  周中={2} 节假日={3}" -f $p.IsPeak, $p.Window, $p.Weekday, $p.Holiday
  return
}

# ---------- 界面 ----------
$script:form = New-Object Windows.Forms.Form
$script:form.Text            = 'DeepSeek 余额挂件'
$script:form.FormBorderStyle = 'None'
$script:form.StartPosition   = 'Manual'
$script:form.TopMost         = $true
$script:form.ShowInTaskbar   = $true
$script:form.Size            = New-Object Drawing.Size(194, 108)

# DoubleBuffered 是受保护属性，需用反射设置
try {
  $dp = [System.Windows.Forms.Control].GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]'Instance,NonPublic')
  if ($dp) { $dp.SetValue($script:form, $true, $null) }
} catch { }

$wa = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$script:form.Location = New-Object Drawing.Point(($wa.Right - $script:form.Width - 24), ($wa.Bottom - $script:form.Height - 24))

function New-Label([string]$text, [single]$size, [bool]$bold, [int]$x, [int]$y) {
  $l = New-Object Windows.Forms.Label
  $l.Text      = $text
  $style       = if ($bold) { [Drawing.FontStyle]::Bold } else { [Drawing.FontStyle]::Regular }
  $l.Font      = New-Object Drawing.Font('Microsoft YaHei UI', $size, $style)
  $l.BackColor = [Drawing.Color]::Transparent
  $l.AutoSize  = $true
  $l.Location  = New-Object Drawing.Point($x, $y)
  $l
}

$script:lblTitle = New-Label 'DeepSeek' 9 $true  12 8
$script:lblBal   = New-Label '余额 --'     15 $true  10 27
$script:lblToday = New-Label '今日已用 --'  9 $false 12 61
$script:lblInfo  = New-Label '初始化…'      8 $false 12 82

$script:lblBadge = New-Label '⚡高峰' 9 $true 140 8
$script:lblBadge.ForeColor = [Drawing.Color]::FromArgb(255, 120, 60)
$script:lblBadge.Visible   = $false

$script:form.Controls.AddRange(@($script:lblTitle, $script:lblBal, $script:lblToday, $script:lblInfo, $script:lblBadge))

function Update-Ui {
  # 每次刷新顺带更新峰谷状态（日期/时段可能变化）
  $script:peak = Get-PeakState
  $script:lblBadge.Visible = $script:peak.IsPeak
  if ($script:peakShown -ne $script:peak.IsPeak) {
    $script:peakShown = $script:peak.IsPeak
    $script:form.Invalidate()
  }

  $s = $script:state
  if ($null -ne $s.Balance) {
    $script:lblBal.Text = '余额 {0:N2}{1}' -f $s.Balance, (Get-CurrencySymbol $s.Currency)
  } else {
    $script:lblBal.Text = '余额 --'
  }
  if ($null -ne $s.Today) {
    $script:lblToday.Text = '今日已用 {0:N2}' -f $s.Today
  }
  if ($s.Error -eq '未配置密钥') {
    $script:lblInfo.Text = '右键 → 设置密钥'
  } elseif ($s.Error) {
    $stamp = if ($s.UpdatedAt) { $s.UpdatedAt.ToString('HH:mm:ss') } else { '--:--:--' }
    $script:lblInfo.Text = "$($s.Error) · $stamp"
  } elseif ($s.UpdatedAt) {
    $script:lblInfo.Text = '更新 ' + $s.UpdatedAt.ToString('HH:mm:ss')
  }
}

# ---------- 圆角 / 边框 ----------
function New-RoundedPath([int]$w, [int]$h, [int]$r) {
  $p = New-Object Drawing.Drawing2D.GraphicsPath
  if ($r -lt 1) {
    $p.AddRectangle((New-Object Drawing.Rectangle(0, 0, $w, $h)))
    return $p
  }
  $d = $r * 2
  $p.AddArc(0, 0, $d, $d, 180, 90)
  $p.AddArc($w - $d - 1, 0, $d, $d, 270, 90)
  $p.AddArc($w - $d - 1, $h - $d - 1, $d, $d, 0, 90)
  $p.AddArc(0, $h - $d - 1, $d, $d, 90, 90)
  $p.CloseFigure()
  $p
}

function Set-RoundedRegion {
  $t = $script:theme
  if ($t.radius -lt 1) { $script:form.Region = $null; return }
  $p = New-RoundedPath $script:form.Width $script:form.Height $t.radius
  $script:form.Region = New-Object Drawing.Region($p)
}

$script:form.Add_Paint({
  param($sender, $e)
  $t = $script:theme
  $e.Graphics.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $p = New-RoundedPath ($sender.Width - 1) ($sender.Height - 1) $t.radius
  if ($script:peak -and $script:peak.IsPeak) {
    # 高峰时段：醒目橙色粗边
    $pen = New-Object Drawing.Pen([Drawing.Color]::FromArgb(255, 120, 60), 2)
  } else {
    $pen = New-Object Drawing.Pen($t.border, 1)
  }
  $e.Graphics.DrawPath($pen, $p)
  $pen.Dispose(); $p.Dispose()
})

# ---------- 主题应用 ----------
function Save-Theme([string]$id) {
  try {
    (@{ theme = $id } | ConvertTo-Json) | Set-Content -Path $script:ThemeFile -Encoding UTF8
  } catch { }
}

function Get-SavedTheme {
  if (Test-Path $script:ThemeFile) {
    try {
      $j = Get-Content -Path $script:ThemeFile -Raw | ConvertFrom-Json
      if ($j.theme) { return (Get-ThemeById ([string]$j.theme)) }
    } catch { }
  }
  return $script:Themes[0]
}

function Apply-ThemeVisual {
  $t = $script:theme
  $script:form.BackColor     = $t.bg
  $script:form.Opacity       = $t.opacity
  $script:lblTitle.ForeColor = $t.muted
  $script:lblBal.ForeColor   = $t.accent
  $script:lblToday.ForeColor = $t.fg
  $script:lblInfo.ForeColor  = $t.muted
  Set-RoundedRegion
  $script:form.Invalidate()
}

function Apply-Theme($t) {
  $script:theme = $t
  Apply-ThemeVisual
  Save-Theme $t.id
}

# ---------- OpenCode 自启开关 ----------
function Get-OpenCodeAutoStart {
  if (Test-Path $script:OpenCodeFlag) {
    try { return [bool](Get-Content $script:OpenCodeFlag -Raw | ConvertFrom-Json).enabled } catch { return $false }
  }
  return $false
}

function Set-OpenCodeAutoStart([bool]$enabled) {
  (@{ enabled = $enabled } | ConvertTo-Json) | Set-Content -Path $script:OpenCodeFlag -Encoding UTF8
  # 交给后台脚本处理开机启动项与监听进程（开启加 -Disable 时代表关闭）
  try {
    $spArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden',
              '-File', (Join-Path $script:Root 'opencode-autostart-set.ps1'))
    if (-not $enabled) { $spArgs += '-Disable' }
    Start-Process -FilePath 'powershell.exe' -ArgumentList $spArgs -WindowStyle Hidden
  } catch { }
}

# ---------- 高峰时段醒目提醒 ----------
function Show-PeakToast {
  $peak = Get-PeakState
  if (-not $peak.IsPeak) { return }

  $script:toast = New-Object Windows.Forms.Form
  $script:toast.FormBorderStyle = 'None'
  $script:toast.StartPosition   = 'Manual'
  $script:toast.TopMost         = $true
  $script:toast.ShowInTaskbar   = $false
  $script:toast.Size            = New-Object Drawing.Size(238, 96)
  $script:toast.BackColor       = [Drawing.Color]::FromArgb(198, 66, 22)

  $f = $script:form
  $x = [Math]::Max(0, ($f.Left + $f.Width - $script:toast.Width))
  $y = [Math]::Max(0, ($f.Top - $script:toast.Height - 8))
  $script:toast.Location = New-Object Drawing.Point($x, $y)

  $mk = {
    param([string]$text, [single]$size, [bool]$bold, [int]$yy, [Drawing.Color]$color)
    $l = New-Object Windows.Forms.Label
    $l.Text = $text
    $style = if ($bold) { [Drawing.FontStyle]::Bold } else { [Drawing.FontStyle]::Regular }
    $l.Font = New-Object Drawing.Font('Microsoft YaHei UI', $size, $style)
    $l.ForeColor = $color
    $l.BackColor = [Drawing.Color]::Transparent
    $l.AutoSize = $true
    $l.Location = New-Object Drawing.Point(14, $yy)
    $l
  }
  $t1 = & $mk '⚡ 高峰时段' 12 $true 10 ([Drawing.Color]::White)
  $t2 = & $mk ("当前 " + $peak.Window) 9 $false 40 ([Drawing.Color]::FromArgb(255, 236, 226))
  $t3 = & $mk '工作日计费较高，请注意用量' 8 $false 64 ([Drawing.Color]::FromArgb(255, 222, 208))

  $script:toast.Controls.AddRange(@($t1, $t2, $t3))
  $script:toast.Region = New-Object Drawing.Region((New-RoundedPath $script:toast.Width $script:toast.Height 14))

  $script:toastTimer = New-Object Windows.Forms.Timer
  $script:toastTimer.Interval = 8000
  $script:toastTimer.Add_Tick({ $script:toastTimer.Stop(); $script:toast.Close() })
  $script:toastTimer.Start()

  $dismiss = { $script:toastTimer.Stop(); $script:toast.Close() }
  foreach ($c in @($script:toast, $t1, $t2, $t3)) { $c.Add_Click($dismiss) }

  $script:toast.Show()
}

# ---------- 拖动 ----------
$script:dragOff = $null
$onDown = {
  $c = [Windows.Forms.Cursor]::Position
  $script:dragOff = New-Object Drawing.Point(($c.X - $script:form.Left), ($c.Y - $script:form.Top))
}
$onMove = {
  if ($null -ne $script:dragOff) {
    $c = [Windows.Forms.Cursor]::Position
    $script:form.Location = New-Object Drawing.Point(($c.X - $script:dragOff.X), ($c.Y - $script:dragOff.Y))
  }
}
$onUp = { $script:dragOff = $null }

# ---------- 右键菜单 ----------
$menu = New-Object Windows.Forms.ContextMenuStrip
$miRefresh = $menu.Items.Add('立即刷新')

$miTheme = New-Object Windows.Forms.ToolStripMenuItem('主题')
foreach ($t in $script:Themes) {
  $item = New-Object Windows.Forms.ToolStripMenuItem($t.name)
  $item.Tag = $t.id
  $item.Add_Click({
    param($sender, $e)
    Apply-Theme (Get-ThemeById ([string]$sender.Tag))
  })
  [void]$miTheme.DropDownItems.Add($item)
}
[void]$menu.Items.Add($miTheme)

$miOpenCode = New-Object Windows.Forms.ToolStripMenuItem('随 OpenCode 启动')
$miOpenCode.CheckOnClick = $true
$miOpenCode.Checked = (Get-OpenCodeAutoStart)
$miOpenCode.Add_Click({
  param($sender, $e)
  Set-OpenCodeAutoStart ([bool]$sender.Checked)
})
[void]$menu.Items.Add($miOpenCode)

$miKey    = $menu.Items.Add('设置密钥…')
$miFolder = $menu.Items.Add('打开数据文件夹')
$null     = $menu.Items.Add((New-Object Windows.Forms.ToolStripSeparator))
$miExit   = $menu.Items.Add('退出')

$miRefresh.Add_Click({ Update-Balance; Update-Ui })
$miExit.Add_Click({ $script:form.Close() })
$miKey.Add_Click({
  Start-Process -FilePath 'powershell.exe' -ArgumentList @(
    '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', (Join-Path $script:Root 'set-key.ps1')
  )
})
$miFolder.Add_Click({ Start-Process -FilePath 'explorer.exe' -ArgumentList $script:Root })

$refreshAndUi = { Update-Balance; Update-Ui }
foreach ($ctl in @($script:form, $script:lblTitle, $script:lblBal, $script:lblToday, $script:lblInfo, $script:lblBadge)) {
  $ctl.Add_MouseDown($onDown)
  $ctl.Add_MouseMove($onMove)
  $ctl.Add_MouseUp($onUp)
  $ctl.Add_DoubleClick($refreshAndUi)
  $ctl.ContextMenuStrip = $menu
}

# ---------- 启动 ----------
$script:theme = Get-SavedTheme
Apply-ThemeVisual

Update-Balance
Update-Ui

# 启动时若处于高峰时段，弹出醒目提醒
$script:form.Add_Shown({ Update-Ui; Show-PeakToast })

$timer = New-Object Windows.Forms.Timer
$timer.Interval = $script:RefreshSec * 1000
$timer.Add_Tick({ Update-Balance; Update-Ui })
$timer.Start()

[void]$script:form.ShowDialog()
$timer.Stop()
