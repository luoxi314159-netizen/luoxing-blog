@echo off
chcp 65001 >nul
set "PS=powershell"
where pwsh >nul 2>nul && set "PS=pwsh"
start "" %PS% -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0widget.ps1"
exit /b
