﻿# 开关「随 OpenCode 自启」
#   开启：写入开关文件 + 加入开机启动项 + 立即运行后台监听
#   关闭：写入开关文件 + 移除开机启动项 + 停止后台监听
# 用法：opencode-autostart-set.ps1            开启
#       opencode-autostart-set.ps1 -Disable   关闭

param([switch]$Disable)
$Enabled = -not $Disable

$ErrorActionPreference = 'SilentlyContinue'
$dir         = Split-Path -Parent $MyInvocation.MyCommand.Path
$flag        = Join-Path $dir 'opencode-autostart.json'
$watchScript = Join-Path $dir 'opencode-watch.ps1'
$startup     = [Environment]::GetFolderPath('Startup')
$lnk         = Join-Path $startup 'DeepSeekBalance-OpenCodeWatch.lnk'

function Get-Watcher {
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -and $_.CommandLine -like '*-File*opencode-watch.ps1*' }
}

(@{ enabled = $Enabled } | ConvertTo-Json) | Set-Content -Path $flag -Encoding UTF8

if ($Enabled) {
  # 开机启动项
  $ws = New-Object -ComObject WScript.Shell
  $s  = $ws.CreateShortcut($lnk)
  $s.TargetPath       = 'powershell.exe'
  $s.Arguments        = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $watchScript + '"'
  $s.WorkingDirectory = $dir
  $s.WindowStyle      = 7
  $s.Description      = 'OpenCode 余额挂件监听'
  $s.Save()

  # 立即启动监听
  if (-not (Get-Watcher)) {
    Start-Process -FilePath 'powershell.exe' -ArgumentList @(
      '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', $watchScript
    ) -WindowStyle Hidden
  }

  Write-Host '随 OpenCode 自启: 已开启' -ForegroundColor Green
  Write-Host '（已加入开机启动；打开 OpenCode 时会自动启动挂件）'
} else {
  if (Test-Path $lnk) { Remove-Item $lnk -Force }
  Get-Watcher | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  Write-Host '随 OpenCode 自启: 已关闭' -ForegroundColor Yellow
}
